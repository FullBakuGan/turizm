document.getElementById('registrationForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const repeatPassword = document.getElementById('repeatPassword').value;
    const errorElement = document.getElementById('passwordError');
    
    // Сброс предыдущих ошибок
    errorElement.textContent = '';
    
    // Валидация паролей
    if (password !== repeatPassword) {
        errorElement.textContent = 'Пароли не совпадают!';
        return;
    }
    
    // Дополнительные проверки (можно добавить больше)
    if (password.length < 6) {
        errorElement.textContent = 'Пароль должен содержать минимум 6 символов';
        return;
    }
    
    // Если все проверки пройдены
    alert('Регистрация успешна!');
    // Здесь можно добавить отправку данных на сервер
    // this.submit();
});

/* REGISTRATION */

