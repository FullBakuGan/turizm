from django.contrib import admin
from django.urls import path, include
from django.views.generic.base import RedirectView
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('index/', views.index_view, name='index'),
    path('api/attractions/', views.attractions_api, name='api-attractions'),
    
    # URL для авторизации
    path('auth/login/', views.login_view, name='login'),
    path('auth/registration/', views.registration_view, name='registration'),
    
    # Подключаем стандартные auth URLs (включая сброс пароля)
    path('auth/', include('django.contrib.auth.urls')),
    
    # Профиль
    path('profile/user/', views.user_view, name='user-profile'),
    path('profile/explored_places/', views.exploared_places_view, name='explored-places'),
    
    # Перенаправления
    path('auth/', RedirectView.as_view(url='/auth/registration/')),  # Основная страница авторизации
    path('login/', RedirectView.as_view(url='/auth/login/')),  # Для старых ссылок
    path('ptofile/', RedirectView.as_view(url = '/profile/user/')), #Профиль юзера
    path('places/', RedirectView.as_view(url = '/profile/explored_places/')), #Исследованные места
    path('', RedirectView.as_view(url='/auth/login/')),  # Главная страница
    
]