from django.contrib import admin
from django.urls import path, include
from django.views.generic.base import RedirectView
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('index/', views.index_view, name='index'),
    path('api/attractions/', views.attractions_api, name='api-attractions'),
    
    # URL для авторизации
    path('auth/login/', views.login_view, name='login'),
    path('auth/registration/', views.registration_view, name='registration'),
    
    # Подключаем стандартные auth URLs (включая сброс пароля)
    path('auth/', include('django.contrib.auth.urls')),
    
    # Перенаправления
    path('auth/', RedirectView.as_view(url='/auth/registration/')),  # Основная страница авторизации
    path('login/', RedirectView.as_view(url='/auth/login/')),  # Для старых ссылок
    path('', RedirectView.as_view(url='/auth/login/')),  # Главная страница
]