# views.py
from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.contrib.auth.forms import UserCreationForm
import json
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import authenticate, login

def index_view(request):
    attractions = [
        {"name": "Краснодар", "coordinates": [45.0333, 38.9833]},
        {"name": "Сочи", "coordinates": [43.5855, 39.7231]},
    ]
    return render(request, 'index.html', {
        'attractions_json': json.dumps(attractions)
    })

def attractions_api(request):
    attractions = [
        {"name": "Краснодар", "coordinates": [45.0355, 38.9753]},
        {"name": "Сочи", "coordinates": [43.5855, 39.7231]},
    ]
    return JsonResponse(attractions, safe=False)

def login_view(request):
    if request.method == 'POST':
        # Используем email как username
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        # Аутентифицируем пользователя
        user = authenticate(request, username=email, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('index')  # Перенаправление на главную страницу
        else:
            # Если аутентификация не удалась
            return render(request, 'avtorization/login.html', {'form': AuthenticationForm(), 'error': 'Неверный email или пароль'})
    return render(request, 'avtorization/login.html', {'form': AuthenticationForm()})

def registration_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'avtorization/registration.html', {'form': form})